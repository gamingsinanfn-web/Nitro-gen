⚠️ Im no longer maintaining this script and the rust version, but maybe I'll rewrite my [nitro sniper](https://github.com/lnxcz/discord-sniper) because theres actually somewhat big chance to snipe nitro if used properly. I kinda want to make it good so it will definitely take a while to create.

# A fast nitro gen w/ proxy-scraper built-in.

<p align="center">
    <a href="https://mit-license.org/">
      <img src= "https://user-images.githubusercontent.com/67145585/134778810-3ed67ef3-8699-42b9-80f3-6a2618d128b3.jpg"/>
    </a>
    <a href="https://www.python.org/">
      <img src="http://ForTheBadge.com/images/badges/made-with-python.svg" />
    </a>
  </p>
</p>

## This program is just a showcase of discord vulnerabilities, I am not responsible of any damage or illegal activity made with this software, assume being a script kiddie and take responsabilities of your damages.

## Table of content:<br/>

### 1. [Downloads](https://github.com/lnxcz/nitro-generator#download) <br/>

### 2. [About the program](https://github.com/lnxcz/nitro-generator#about-the-program) <br/>

### 2. [What's new?](https://github.com/lnxcz/nitro-generator/blob/master/README.md#whats-new) <br/>

### 3. [Requirements](https://github.com/lnxcz/nitro-generator#requirements)

### 4. [How to run and use the software?](https://github.com/lnxcz/nitro-generator#run-and-use-the-software)

### 6. [Special cases and internal errors](https://github.com/lnxcz/nitro-generator#special-cases-and-internal-errors)

<br/><br/>

# Download

[![hey](https://img.shields.io/badge/Download%20.py-181717?style=for-the-badge&color=black&logo=python)](https://github.com/lnxcz/nitro-generator/archive/refs/heads/master.zip)

# About the program

Program created by: [lnxcz](https://github.com/lnxcz)

Improved by: [DR34M-M4K3R](https://github.com/DR34M-M4K3R)

Improved again by: [ledges](https://github.com/ledges)

<br/>
<br/>

# What's new?

- Massive code cleanup
- Easily Selectable Options w/ good looking UI.

<br/>
<br/>

# Requirements:

- Python 3 (tested on 3.7 and 3.8)
- Everything in `requirements.txt`

<br/><br/>

# Run and use the software

#### Install dependencies (optional)

Open a terminal, go to the nitro-generator directory and type:

```
$ pip3 install -r requirements.txt
```

<br/><br/>

#### Run the .py file

To run the main.py file, you need to open a terminal, go to the main.py directory and type:

```
$ python3 main.py
```

## How to use nitro-generator?

#### 1- [Download](https://github.com/lnxcz/nitro-generator#download)

#### 2- [Run the program](https://github.com/lnxcz/nitro-generator#run-and-use-the-software)

#### 3- Answer questions displayed on the terminal.

<br/>
<br/>

# Special cases and internal errors

<br/><br/>

### Problem 1 - No module named ...

```
ModuleNotFoundError: No module named ...
```

Install dependencies (see [here](https://github.com/lnxcz/nitro-generator#downloads))
<br/>

### Problem 2 - A very long error displayed

![Screenshot_20210925_180856](https://user-images.githubusercontent.com/67145585/134778134-eaa9e531-15e7-4140-afae-16a8dd33cce7.png)

The problem that is being shown here is ratelimit, you're proxies / IP is most likely being ratelimited by the service that is being scraped from.
<br/><br/>

## Showcase:

![image](https://user-images.githubusercontent.com/120739758/219971344-631c978f-cb7e-44d0-aa45-56b727ed2487.png)
<br>
